# Verifica della versione 1.2

- Test browser Chromium: superati riconoscimento categoria Supermercato, scelta manuale appresa, budget mensile complessivo e per categoria, soglie 80% e 100%, deduplicazione delle notifiche con adattatore nativo simulato, esclusione delle entrate, inclusione dei costi fissi, persistenza, rimozione dei limiti, uso offline, migrazione dei dati, consenso negato e cambio di mese.
- Controlli sintassi JavaScript, manifest, icone e plist iOS: superati.
- Build Android Gradle assembleDebug: superata con JDK 21 e SDK 36.
- APK: firma debug verificata con apksigner (schema v2); package it.taccuino.app, versione 1.2.0, min SDK 24, target SDK 36, permesso POST_NOTIFICATIONS presente.
- ZIP del sito e sorgenti: contenuti e integrità verificati; nessuna chiave di firma inclusa. Archivio originale conservato.
- Non eseguiti: test su telefoni fisici, consegna delle notifiche da parte del sistema operativo, compilazione iOS (richiede macOS/Xcode), firma release e pubblicazione negli store.
