# Taccuino 1.2

Gestione spese e promemoria, basata sull'HTML di `Taccuino_iphone.zip` (conservato invariato). I sorgenti aggiornati sono in `web/`. Lo stesso sito viene incorporato nelle app Android e iOS con Capacitor.

## Novità

- Budget mensile complessivo e limiti mensili indipendenti per Utilità, Svago, Supermercato e Costi fissi. Nessun importo viene impostato senza una scelta dell'utente.
- Avvisi all'80% e al 100%, importo residuo e indicazione dello sforamento. Il budget complessivo comprende i costi fissi; le entrate non riducono le spese. Il limite è un avviso e non impedisce di registrare altre spese.
- Notifiche locali Android/iOS con consenso esplicito, attivabili e disattivabili. Ogni soglia viene notificata una volta per mese/categoria; se una modifica porta le spese sotto la soglia, un successivo raggiungimento può produrre un nuovo avviso.
- Categoria Supermercato riconosciuta da parole e insegne (es. Lidl, Conad, Coop, Esselunga, Eurospin). L'insegna del supermercato ha priorità sulle parole di prodotto; la scelta manuale e le categorie già apprese restano prioritarie. Le vecchie spese non vengono ricategorizzate automaticamente.
- Sito installabile e offline dopo il primo caricamento, oltre alle app native. Interfaccia mobile, icone, etichette accessibili e rispetto della preferenza di movimento ridotto.

I controlli delle soglie avvengono al salvataggio/modifica/eliminazione, all'avvio e al ritorno nell'app. Non è presente un servizio push o un processo in background che controlla il budget mentre l'app è chiusa. I costi fissi del nuovo mese vengono verificati alla riapertura. Gli avvisi nell'app funzionano anche senza autorizzazione alle notifiche.

## Sviluppo sito

Richiede Node.js 22 o successivo (verificato con Node 24) e Python 3 per il server di sviluppo.

```sh
npm ci
npm run build
npm run dev
```

Il server usa la porta 8001. Per pubblicare il sito, caricare l'intera cartella `web/` su un hosting HTTPS, non soltanto `index.html`. Su iPhone le notifiche web richiedono iOS 16.4+ e l'installazione sulla schermata Home; l'app nativa usa invece il plugin di notifiche locali. Per aprire il solo HTML senza build usare il pacchetto sito precompilato fornito nella consegna.

## Android

Android 7.0+; target/compile SDK 36, Java JDK 21. Installare Android Studio e i pacchetti SDK 36, Build Tools 35.0.0 (selezionati da Gradle) e Platform Tools.

```sh
npm ci
npm run sync
npm run android
```

Da Android Studio configurare l'SDK; oppure impostare `ANDROID_HOME` e `JAVA_HOME`, quindi:

```sh
cd android
./gradlew --max-workers=2 assembleDebug
```

APK di prova: `android/app/build/outputs/apk/debug/app-debug.apk`. Per Google Play generare un Android App Bundle di release firmato con la propria chiave, impostare un application ID definitivo, aggiornare versionCode e seguire la procedura di pubblicazione di Play Console. Non includere le chiavi nel repository. Un APK debug serve per le prove e non è un pacchetto da pubblicare nello store.

## iOS

iOS 15+; richiede un Mac, Xcode compatibile con Capacitor 8 (26+), e un account Apple Developer per distribuzione/TestFlight/App Store.

```sh
npm ci
npm run ios
```

Il progetto è `ios/App/App.xcodeproj`, con dipendenze Swift Package Manager. In Xcode scegliere il proprio Team, verificare il Bundle Identifier (iniziale `it.taccuino.app`), eseguire su un iPhone, quindi Product → Archive e distribuire tramite App Store Connect. Le notifiche sono locali: non richiedono APNs, Firebase o certificati push. La build iOS non può essere eseguita nell'ambiente cloud Linux usato per questa consegna.

## Dati

Nel sito e nelle nuove app Capacitor i dati restano sul dispositivo, in localStorage. È mantenuto il supporto AndroidBridge già presente nell'HTML per eventuali wrapper Android esistenti. La lettura dei dati della versione precedente sulla stessa origine mantiene transazioni e categorie e aggiunge budget disattivati. Sito, APK e app iOS hanno archivi separati: i dati non vengono sincronizzati e non vengono trasferiti automaticamente da un vecchio APK con un diverso contenitore. Non disinstallare un'app con dati importanti prima di averli esportati tramite il suo sistema esistente.

## Verifiche

Con il server di sviluppo attivo, installare Playwright Python e usare Chromium:

```sh
python3 -m pip install -r tests/requirements.txt
python3 tests/smoke.py
```

Il test verifica riconoscimento categorie, scelta manuale appresa, budget complessivo/per categoria, soglie esatte 80%/100%, deduplicazione tramite simulazione dell'adattatore nativo, entrate, costi fissi, persistenza, rimozione del limite, uso offline, layout mobile e migrazione dei dati precedenti. `CHROMIUM_PATH` e `TACCUINO_TEST_URL` permettono di cambiare browser e server. I test browser non sostituiscono una verifica su telefoni reali, in particolare per consenso e consegna delle notifiche native.
